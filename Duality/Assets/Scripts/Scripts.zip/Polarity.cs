using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Polarity : MonoBehaviour
{
   public enum PolarityType
    {
        north, 
        south
    }
    public PolarityType polarityType;
}
